//Ctievers = new Mongo.Collection('ctievers');
//if (Ctievers.find().count() === 0) {
//          Ctievers.insert({
//            name: '1505N',
//            verno:'F-CTIE V2.52.01.00',
//            desc: ''
//          });
//
//          Ctievers.insert({
//            name: '1505N1',
//            verno:'F-CTIE V2.52.02001.0',
//            desc: ''
//          });
//          Ctievers.insert({
//            name: '1507N',
//            verno:'F-CTIE V2.54.01.00',
//            desc: ''
//          });
//          Ctievers.insert({
//            name: '1507N1',
//            verno:'F-CTIE V2.54.01001.00',
//            desc: ''
//          });
//          Ctievers.insert({
//            name: '1507N',
//            verno:'F-CTIE V2.54.01.01',
//            desc: ''
//          });
//          Ctievers.insert({
//            name: '1507N1',
//            verno:'F-CTIE V2.54.01001.01',
//            desc: ''
//          });
//          Ctievers.insert({
//            name: '1507N',
//            verno:'F-CTIE V2.54.01.02',
//            desc: ''
//          });
//          Ctievers.insert({
//            name: '1507N1',
//            verno:'F-CTIE V2.54.01001.02',
//            desc: ''
//          });
//          Ctievers.insert({
//            name: '1508N',
//            verno:'F-CTIE V2.55.01.00',
//            desc: ''
//          });
//          Ctievers.insert({
//            name: '1508N1',
//            verno:'F-CTIE V2.55.01001.00',
//            desc: ''
//          });
//
//}
//
